"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseManager = exports.DatabaseObjectList = exports.DatabaseObject = void 0;
class InvalidObjectError extends Error {
    constructor(message) {
        super(message);
    }
}
class DatabaseObject {
    constructor(database, collection, data) {
        this.database = database;
        this.collection = collection;
        this.data = data;
    }
}
exports.DatabaseObject = DatabaseObject;
class DatabaseObjectList {
    constructor(database, collection, data) {
        this.database = database;
        this.collection = collection;
        this.data = data;
    }
}
exports.DatabaseObjectList = DatabaseObjectList;
class DatabaseManager {
    constructor(client) {
        this.client = client;
    }
    insert(obj) {
        if (obj instanceof DatabaseObject) {
            return this.client
                .db(obj.database)
                .collection(obj.collection)
                .insertOne(obj.data);
        }
        else if (obj instanceof DatabaseObjectList) {
            return this.client
                .db(obj.database)
                .collection(obj.collection)
                .insertMany(obj.data);
        }
        throw new InvalidObjectError("The object supplied is not a DatabaseObjecct or a DatabaseObjectList!");
    }
    getObject(searchObj) {
        return this.client
            .db(searchObj.database)
            .collection(searchObj.collection)
            .findOne(searchObj.data, {});
    }
    getMultipleObjects(searchObj) {
        return this.client
            .db(searchObj.database)
            .collection(searchObj.collection)
            .find(searchObj.data, {});
    }
}
exports.DatabaseManager = DatabaseManager;
//# sourceMappingURL=index.js.map