"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const database_ = (0, tslib_1.__importStar)(require("./index"));
const UserModel_1 = (0, tslib_1.__importDefault)(require("../models/UserModel"));
const UserCache = async (database, client) => {
    const dbmanager = new database_.DatabaseManager(client);
    const users = [];
    try {
        const objs = await dbmanager.getMultipleObjects({
            collection: "users",
            database: database,
            data: {},
        });
        objs.forEach((doc) => {
            if (!doc ||
                !doc.name ||
                !doc.username ||
                !doc.email ||
                !doc.uuid ||
                !doc.credentials ||
                !doc.credentials.hash ||
                !doc.credentials.salt ||
                !doc._id)
                return;
            users.push(new UserModel_1.default(doc.name, doc.username, doc.email, doc.uuid, doc.credentials, doc._id));
        });
    }
    catch (e) {
        console.log(`\x1b[46m\x1b[30m AUTHLIB \x1b[0m \x1b[41m\x1b[30m ERROR \x1b[0m An error occured while getting users from the database.`);
    }
    return {
        users,
        getUser: async (username) => {
            try {
                const doc = await dbmanager.getObject({
                    collection: "users",
                    database: database,
                    data: { username: username },
                });
                if (!doc ||
                    !doc.name ||
                    !doc.username ||
                    !doc.email ||
                    !doc.uuid ||
                    !doc.credentials ||
                    !doc.credentials.hash ||
                    !doc.credentials.salt ||
                    !doc._id)
                    return null;
                return new UserModel_1.default(doc.name, doc.username, doc.email, doc.uuid, doc.credentials, doc._id);
            }
            catch (e) {
                console.log(`\x1b[46m\x1b[30m AUTHLIB \x1b[0m \x1b[41m\x1b[30m ERROR \x1b[0m An error occured while getting a user from the database.`);
                return null;
            }
        },
        getUserByUUID: async (uuid) => {
            try {
                const doc = await dbmanager.getObject({
                    collection: "users",
                    database: database,
                    data: { uuid: uuid },
                });
                if (!doc ||
                    !doc.name ||
                    !doc.username ||
                    !doc.email ||
                    !doc.uuid ||
                    !doc.credentials ||
                    !doc.credentials.hash ||
                    !doc.credentials.salt ||
                    !doc._id)
                    return null;
                return new UserModel_1.default(doc.name, doc.username, doc.email, doc.uuid, doc.credentials, doc._id);
            }
            catch (e) {
                console.log(`\x1b[46m\x1b[30m AUTHLIB \x1b[0m \x1b[41m\x1b[30m ERROR \x1b[0m An error occured while getting a user from the database.`);
                return null;
            }
        },
        getCachedUser: (username) => {
            for (let i = 0; i < users.length; i++) {
                if (users[i].username == username)
                    return users[i];
            }
            return null;
        },
        getCachedUserByUUID: (uuid) => {
            for (let i = 0; i < users.length; i++) {
                if (users[i].uuid == uuid)
                    return users[i];
            }
            return null;
        },
    };
};
exports.default = UserCache;
//# sourceMappingURL=usercache.js.map