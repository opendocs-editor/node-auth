/// <reference types="express-serve-static-core" />
import express from "express";
interface MongoDBOptions {
    host?: string;
    port?: number;
    user?: string;
    pass?: string;
}
export interface ErrorObject {
    [key: string]: string;
}
interface AuthOptions {
    useGoogleAuth?: boolean;
    googleAuth?: {
        clientId?: string;
        clientSecret?: string;
        websiteBaseUrl?: string;
    };
    useGithubAuth?: boolean;
    githubAuth?: {
        clientId?: string;
        clientSecret?: string;
        websiteBaseUrl?: string;
        scope?: string;
        accessToken?: string;
    };
    useInternalAuth?: boolean;
}
declare const useAuth: (app: express.Express, database: string, masterToken: string, mongodbOptions?: MongoDBOptions | undefined, authOptions?: AuthOptions | undefined) => Promise<void>;
export default useAuth;
