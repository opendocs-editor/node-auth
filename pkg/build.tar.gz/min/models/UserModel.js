"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class UserModel {
    constructor(name, username, email, uuid, credentials, _id) {
        this.name = name;
        this.username = username;
        this.email = email;
        this.uuid = uuid;
        this.credentials = credentials;
        this._id = _id;
    }
}
exports.default = UserModel;
//# sourceMappingURL=UserModel.js.map