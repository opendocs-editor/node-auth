import mongodb from "mongodb";
declare class Token {
    value?: string | undefined;
    holder?: string | undefined;
    _id?: mongodb.ObjectId | undefined;
    constructor(value?: string | undefined, holder?: string | undefined, _id?: mongodb.ObjectId | undefined);
}
export default Token;
