import { OAuth2Client } from "google-auth-library";
declare const _default: {
    create: (clientId: string, clientSecret: string, websiteBaseUrl: string) => OAuth2Client;
    createAuthUrl: (client: OAuth2Client) => string;
    getGooglePlusApi: (client: OAuth2Client) => import("googleapis").plus_v1.Plus;
    getAccountFromCode: (code: string, client: OAuth2Client, clientId: string, clientSecret: string, websiteBaseUrl: string) => Promise<{
        id: string | null | undefined;
        email: string | 0 | null | undefined;
        tokens: import("google-auth-library").Credentials;
    }>;
};
export default _default;
