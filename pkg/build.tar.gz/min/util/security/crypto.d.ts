export interface PasswordHash {
    hash: string;
    salt: string;
}
export interface HashObjectConversion {
    [key: string]: string;
}
export declare const toPasswordHash: (hash: object) => PasswordHash;
export declare const hashPassword: (password: string) => PasswordHash;
export declare const checkPassword: (hash: PasswordHash, passwordToCheck: string) => boolean;
declare const _default: {};
export default _default;
