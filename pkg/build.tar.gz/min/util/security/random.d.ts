export declare const randomString: (length?: number | undefined) => string;
export declare const random: (min?: number, max?: number, whole?: boolean) => number;
