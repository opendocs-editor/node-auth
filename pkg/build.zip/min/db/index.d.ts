import mongodb from "mongodb";
export declare class DatabaseObject {
    database: string;
    collection: string;
    data: object;
    constructor(database: string, collection: string, data: object);
}
export declare class DatabaseObjectList {
    database: string;
    collection: string;
    data: object[];
    constructor(database: string, collection: string, data: object[]);
}
export declare class DatabaseManager {
    private client;
    constructor(client: mongodb.MongoClient);
    insert(obj: DatabaseObject): Promise<mongodb.InsertOneResult<mongodb.Document>>;
    insert(objs: DatabaseObjectList): Promise<mongodb.InsertManyResult<mongodb.Document>>;
    getObject(searchObj: DatabaseObject): Promise<mongodb.WithId<mongodb.Document> | null>;
    getMultipleObjects(searchObj: DatabaseObject): mongodb.FindCursor<mongodb.WithId<mongodb.Document>>;
}
