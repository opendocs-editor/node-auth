import mongodb from "mongodb";
import UserModel from "../models/UserModel";
declare const UserCache: (database: string, client: mongodb.MongoClient) => Promise<{
    users: UserModel[];
    getUser: (username: string) => Promise<UserModel | null>;
    getUserByUUID: (uuid: string) => Promise<UserModel | null>;
    getCachedUser: (username: string) => UserModel | null;
    getCachedUserByUUID: (uuid: string) => UserModel | null;
}>;
export default UserCache;
