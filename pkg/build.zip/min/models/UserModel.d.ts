import mongodb from "mongodb";
interface UserPasswordCredentials {
    hash: string;
    salt: string;
}
declare class UserModel {
    name?: string | undefined;
    username?: string | undefined;
    email?: string | undefined;
    uuid?: string | undefined;
    credentials?: UserPasswordCredentials | undefined;
    _id?: mongodb.ObjectId | undefined;
    constructor(name?: string | undefined, username?: string | undefined, email?: string | undefined, uuid?: string | undefined, credentials?: UserPasswordCredentials | undefined, _id?: mongodb.ObjectId | undefined);
}
export default UserModel;
