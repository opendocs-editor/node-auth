"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Token {
    constructor(value, holder, _id) {
        this.value = value;
        this.holder = holder;
        this._id = _id;
    }
}
exports.default = Token;
//# sourceMappingURL=Token.js.map