import mongodb from "mongodb";
import Token from "./Token";
declare const TokenCache: (database: string, client: mongodb.MongoClient) => Promise<{
    tokens: Token[];
    getToken: (value: string) => Promise<Token | null>;
    getTokenByHolder: (holder: string) => Promise<Token | null>;
    getCachedToken: (value: string) => Token | null;
    getCachedTokenByHolder: (holder: string) => Token | null;
}>;
export default TokenCache;
