"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const database_ = (0, tslib_1.__importStar)(require("../db/index"));
const Token_1 = (0, tslib_1.__importDefault)(require("./Token"));
const TokenCache = async (database, client) => {
    const dbmanager = new database_.DatabaseManager(client);
    const tokens = [];
    try {
        const objs = await dbmanager.getMultipleObjects({
            collection: "tokens",
            database: database,
            data: {},
        });
        objs.forEach((doc) => {
            if (!doc || !doc.value || !doc.holder || !doc._id)
                return;
            tokens.push(new Token_1.default(doc.value, doc.holder, doc._id));
        });
    }
    catch (e) {
        console.log(`\x1b[46m\x1b[30m AUTHLIB \x1b[0m \x1b[41m\x1b[30m ERROR \x1b[0m An error occured while getting tokens from the database.`);
    }
    return {
        tokens,
        getToken: async (value) => {
            try {
                const doc = await dbmanager.getObject({
                    collection: "tokens",
                    database: database,
                    data: { value: value },
                });
                if (!doc || !doc.value || !doc.holder || !doc._id)
                    return null;
                return new Token_1.default(doc.value, doc.holder, doc._id);
            }
            catch (e) {
                console.log(`\x1b[46m\x1b[30m AUTHLIB \x1b[0m \x1b[41m\x1b[30m ERROR \x1b[0m An error occured while getting a token from the database.`);
                return null;
            }
        },
        getTokenByHolder: async (holder) => {
            try {
                const doc = await dbmanager.getObject({
                    collection: "users",
                    database: database,
                    data: { golder: holder },
                });
                if (!doc || !doc.value || !doc.holder || !doc._id)
                    return null;
                return new Token_1.default(doc.value, doc.holder, doc._id);
            }
            catch (e) {
                console.log(`\x1b[46m\x1b[30m AUTHLIB \x1b[0m \x1b[41m\x1b[30m ERROR \x1b[0m An error occured while getting a token from the database.`);
                return null;
            }
        },
        getCachedToken: (value) => {
            for (let i = 0; i < tokens.length; i++) {
                if (tokens[i].value == value)
                    return tokens[i];
            }
            return null;
        },
        getCachedTokenByHolder: (holder) => {
            for (let i = 0; i < tokens.length; i++) {
                if (tokens[i].holder == holder)
                    return tokens[i];
            }
            return null;
        },
    };
};
exports.default = TokenCache;
//# sourceMappingURL=tokencache.js.map