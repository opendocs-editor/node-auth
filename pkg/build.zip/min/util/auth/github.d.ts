declare const _default: {
    createLoginUrl: (clientId: string, scope: string[], allowSignup: boolean | undefined, websiteBaseUrl: string) => string;
    getAccessTokenFromCode: (code: string, clientId: string, clientSecret: string, websiteBaseUrl: string) => Promise<string>;
    getGitHubUserData: (access_token: string) => Promise<object>;
};
export default _default;
