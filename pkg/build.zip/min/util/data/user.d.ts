import UserModel from "../../models/UserModel";
export declare const createUser: (name: string, username: string, email: string, password_: string) => UserModel;
