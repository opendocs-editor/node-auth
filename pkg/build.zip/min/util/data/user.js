"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUser = void 0;
const tslib_1 = require("tslib");
const uuid = (0, tslib_1.__importStar)(require("uuid"));
const UserModel_1 = (0, tslib_1.__importDefault)(require("../../models/UserModel"));
const crypto = (0, tslib_1.__importStar)(require("../security/crypto"));
const createUser = (name, username, email, password_) => {
    const uid = uuid.v4();
    const password = crypto.hashPassword(password_);
    const user = new UserModel_1.default(name, username, email, uid, password);
    return user;
};
exports.createUser = createUser;
//# sourceMappingURL=user.js.map