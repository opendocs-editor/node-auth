"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkPassword = exports.hashPassword = exports.toPasswordHash = void 0;
const tslib_1 = require("tslib");
const crypto_1 = (0, tslib_1.__importDefault)(require("crypto"));
const toPasswordHash = (hash) => {
    const password = {
        hash: hash.hash,
        salt: hash.salt,
    };
    return password;
};
exports.toPasswordHash = toPasswordHash;
const hashPassword = (password) => {
    const salt = crypto_1.default.randomBytes(16).toString("hex");
    const hash = crypto_1.default
        .pbkdf2Sync(password, salt, 1000, 64, "sha512")
        .toString("hex");
    const returnVal = {
        salt: salt,
        hash: hash,
    };
    return returnVal;
};
exports.hashPassword = hashPassword;
const checkPassword = (hash, passwordToCheck) => {
    const newHash = crypto_1.default
        .pbkdf2Sync(passwordToCheck, hash.salt, 1000, 64, "sha512")
        .toString("hex");
    return hash.hash === newHash;
};
exports.checkPassword = checkPassword;
exports.default = {};
//# sourceMappingURL=crypto.js.map